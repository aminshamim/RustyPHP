
#[derive(Debug, PartialEq)]
pub enum Token {
    PhpOpen,
    Echo,
    String(String),
    Semicolon,
    PhpClose,
    EOF,
}

pub fn lex(input: &str) -> Vec<Token> {
    let mut tokens = Vec::new();
    let mut chars = input.chars().peekable();

    while let Some(&c) = chars.peek() {
        match c {
            '<' if chars.by_ref().take(5).collect::<String>() == "<?php" => {
                tokens.push(Token::PhpOpen);
            }
            'e' if chars.by_ref().take(4).collect::<String>() == "echo" => {
                tokens.push(Token::Echo);
            }
            '\'' => {
                chars.next();
                let mut s = String::new();
                while let Some(&ch) = chars.peek() {
                    if ch == '\'' {
                        chars.next();
                        break;
                    }
                    s.push(ch);
                    chars.next();
                }
                tokens.push(Token::String(s));
            }
            ';' => {
                tokens.push(Token::Semicolon);
                chars.next();
            }
            '?' if chars.by_ref().take(2).collect::<String>() == "?>" => {
                tokens.push(Token::PhpClose);
            }
            _ => { chars.next(); }
        }
    }
    tokens.push(Token::EOF);
    tokens
}
