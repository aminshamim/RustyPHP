
use crate::lexer::Token;

pub enum Node {
    Echo(String),
}

impl Node {
    pub fn execute(&self) {
        match self {
            Node::Echo(content) => println!("{}", content),
        }
    }
}
