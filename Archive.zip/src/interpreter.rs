// src/interpreter.rs
use crate::ast::Node;

pub fn execute(node: Node) -> Result<String, String> {
    let mut output = String::new();
    match node {
        Node::Echo(content) => {
            output.push_str(&content);
        }
    }
    Ok(output)
}
