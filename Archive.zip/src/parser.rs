use crate::lexer::Token;
use crate::ast::Node;

pub fn parse(tokens: Vec<Token>) -> Result<Node, String> {
    let mut iter = tokens.iter();

    // Check for optional PHP opening tag
    if let Some(Token::PhpOpen) = iter.next() {
        // If found, continue parsing
    } else {
        // If not found, reset iterator to start from the beginning
        iter = tokens.iter();
    }

    // Expect the `echo` keyword next
    match iter.next() {
        Some(Token::Echo) => {
            // Expect a string content
            match iter.next() {
                Some(Token::String(content)) => {
                    // Expect a semicolon to end the statement
                    match iter.next() {
                        Some(Token::Semicolon) => Ok(Node::Echo(content.clone())),
                        _ => Err("Expected a semicolon ';' after echo statement".to_string()),
                    }
                }
                _ => Err("Expected a string after echo".to_string()),
            }
        }
        _ => Err("Expected 'echo' after PHP opening tag or as the first statement".to_string()),
    }
}
